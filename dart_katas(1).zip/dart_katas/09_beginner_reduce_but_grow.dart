/// Kata: Beginner - Reduce but Grow (8 kyu)
///
/// Multiplica entre sí todos los valores de una lista.
library;

/// Multiplica todos los elementos de [arr] en orden.
///
/// Parte de 1 (el elemento neutro de la multiplicación) y va multiplicando
/// cada valor con un bucle `for`.
///
/// * [arr]: lista de enteros, no vacía.
///
/// Devuelve el producto de todos los elementos.
///
/// Ejemplo: `grow([1, 2, 3, 4])` devuelve `24`.
int grow(List<int> arr) {
  int resultado = 1;

  for (int i = 0; i < arr.length; i++) {
    resultado *= arr[i];
  }
  return resultado;
}

/// Versión alternativa de [grow] con `reduce`.
///
/// `reduce` combina los elementos de dos en dos: primero `1*2`, luego el
/// resultado `*3`, y así hasta el final.
///
/// * [arr]: lista de enteros, no vacía.
///
/// Devuelve el producto de todos los elementos.
int growV2(List<int> arr) => arr.reduce((acumulado, valor) => acumulado * valor);

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  print('grow([1, 2, 3]) = ${grow([1, 2, 3])}'
      ' | V2: ${growV2([1, 2, 3])} (esperado 6)');
  print('grow([4, 1, 1, 1, 4]) = ${grow([4, 1, 1, 1, 4])}'
      ' | V2: ${growV2([4, 1, 1, 1, 4])} (esperado 16)');
  print('grow([2, 2, 2, 2, 2, 2]) = ${grow([2, 2, 2, 2, 2, 2])}'
      ' | V2: ${growV2([2, 2, 2, 2, 2, 2])} (esperado 64)');
}
