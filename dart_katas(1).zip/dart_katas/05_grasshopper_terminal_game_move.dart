/// Kata: Grasshopper - Terminal game move function (8 kyu)
///
/// El héroe avanza el doble de lo que saca en el dado.
library;

/// Calcula la nueva posición del héroe.
///
/// * [pos]: posición actual del héroe.
/// * [roll]: valor sacado en el dado (de 1 a 6).
///
/// Devuelve la nueva posición: `pos + roll * 2`.
///
/// Ejemplo: `move(3, 6)` devuelve `15`.
int move(int pos, int roll) {
  return pos + (roll * 2);
}

/// Versión alternativa de [move] escrita como función flecha (`=>`).
///
/// Suma la tirada dos veces en lugar de multiplicarla.
///
/// * [pos]: posición actual del héroe.
/// * [roll]: valor sacado en el dado (de 1 a 6).
///
/// Devuelve la nueva posición.
int moveV2(int pos, int roll) => pos + roll + roll;

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  print('move(0, 4) = ${move(0, 4)}  | V2: ${moveV2(0, 4)}  (esperado 8)');
  print('move(3, 6) = ${move(3, 6)} | V2: ${moveV2(3, 6)} (esperado 15)');
  print('move(2, 5) = ${move(2, 5)} | V2: ${moveV2(2, 5)} (esperado 12)');
}
