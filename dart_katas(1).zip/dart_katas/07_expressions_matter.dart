/// Kata: Expressions Matter (8 kyu)
///
/// Con tres números (sin cambiar su orden), los operadores + y * y
/// paréntesis, hay que obtener el valor más alto posible.
library;

import 'dart:math';

/// Calcula el mayor resultado posible combinando [a], [b] y [c].
///
/// Guarda en una lista las seis combinaciones posibles y busca la mayor
/// recorriéndola con un bucle.
///
/// * [a]: primer número (1 a 10).
/// * [b]: segundo número (1 a 10).
/// * [c]: tercer número (1 a 10).
///
/// Devuelve el valor máximo que se puede obtener.
///
/// Ejemplo: `expressionMatter(1, 2, 3)` devuelve `9`, porque `(1 + 2) * 3 = 9`.
int expressionMatter(int a, int b, int c) {
  List<int> resultados = [
    a + b + c,
    a * b * c,
    a + b * c,
    a * b + c,
    (a + b) * c,
    a * (b + c),
  ];

  int mayor = resultados[0];

  for (int i = 1; i < resultados.length; i++) {
    if (resultados[i] > mayor) {
      mayor = resultados[i];
    }
  }
  return mayor;
}

/// Versión alternativa de [expressionMatter] con `reduce` y `max`.
///
/// `reduce(max)` compara los elementos de dos en dos y se queda con el
/// mayor, sin escribir el bucle a mano.
///
/// * [a]: primer número (1 a 10).
/// * [b]: segundo número (1 a 10).
/// * [c]: tercer número (1 a 10).
///
/// Devuelve el valor máximo que se puede obtener.
int expressionMatterV2(int a, int b, int c) {
  return [
    a + b + c,
    a * b * c,
    a + b * c,
    a * b + c,
    (a + b) * c,
    a * (b + c),
  ].reduce(max);
}

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  print('expressionMatter(2, 1, 2) = ${expressionMatter(2, 1, 2)}'
      ' | V2: ${expressionMatterV2(2, 1, 2)} (esperado 6)');
  print('expressionMatter(2, 1, 1) = ${expressionMatter(2, 1, 1)}'
      ' | V2: ${expressionMatterV2(2, 1, 1)} (esperado 4)');
  print('expressionMatter(1, 1, 1) = ${expressionMatter(1, 1, 1)}'
      ' | V2: ${expressionMatterV2(1, 1, 1)} (esperado 3)');
  print('expressionMatter(9, 1, 1) = ${expressionMatter(9, 1, 1)}'
      ' | V2: ${expressionMatterV2(9, 1, 1)} (esperado 18)');
}
