/// Kata: A Rule of Divisibility by 7 (7 kyu)
///
/// Un número `10x + y` es divisible por 7 si y solo si `x - 2y` lo es.
/// Se repite el proceso hasta que el número tenga como mucho 2 cifras.
library;

/// Aplica la regla de divisibilidad por 7 a [m] hasta que tenga 2 cifras o menos.
///
/// En cada paso separa la última cifra (`m % 10`) del resto (`m ~/ 10`)
/// y calcula `resto - 2 * ultima`.
///
/// * [m]: número entero mayor o igual que 0.
///
/// Devuelve una lista `[ultimoNumero, pasos]`: el número final de como
/// mucho 2 cifras y cuántos pasos se han necesitado.
///
/// Ejemplo: `seven(371)` devuelve `[35, 1]`.
List<int> seven(int m) {
  int pasos = 0;

  while (m >= 100) {
    int ultimo = m % 10;
    int resto = m ~/ 10;

    m = resto - (2 * ultimo);
    pasos++;
  }

  return [m, pasos];
}

/// Versión alternativa de [seven] hecha con recursividad.
///
/// Si el número ya tiene 2 cifras o menos, devuelve el resultado.
/// Si no, se llama a sí misma con el siguiente número y un paso más.
///
/// * [m]: número entero mayor o igual que 0.
/// * [pasos]: pasos acumulados; es opcional y vale 0 al empezar.
///
/// Devuelve una lista `[ultimoNumero, pasos]`.
List<int> sevenV2(int m, [int pasos = 0]) {
  if (m < 100) {
    return [m, pasos];
  }
  return sevenV2(m ~/ 10 - 2 * (m % 10), pasos + 1);
}

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  final pruebas = [
    (1021, [10, 2]),
    (477557101, [28, 7]),
    (477557102, [47, 7]),
    (109, [-8, 1]),
    (371, [35, 1]),
  ];

  for (final (n, esperado) in pruebas) {
    print('seven($n) = ${seven(n)} | V2: ${sevenV2(n)} (esperado $esperado)');
  }
}
