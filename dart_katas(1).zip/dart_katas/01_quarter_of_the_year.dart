/// Kata: Quarter of the year (8 kyu)
///
/// Dado un mes (1-12), devuelve el trimestre del año al que pertenece.
library;

/// Calcula el trimestre al que pertenece un mes.
///
/// Suma 2 al mes y hace la división entera entre 3, así los meses
/// 1-3 dan 1, 4-6 dan 2, 7-9 dan 3 y 10-12 dan 4.
///
/// * [month]: número de mes, de 1 (enero) a 12 (diciembre).
///
/// Devuelve el trimestre, un entero de 1 a 4.
///
/// Ejemplo: `quarter(8)` devuelve `3`.
int quarter(int month) {
  return (month + 2) ~/ 3;
}

/// Versión alternativa de [quarter] con `if / else if`.
///
/// Compara el mes con el último mes de cada trimestre.
///
/// * [month]: número de mes, de 1 a 12.
///
/// Devuelve el trimestre, un entero de 1 a 4.
int quarterV2(int month) {
  if (month <= 3) {
    return 1;
  } else if (month <= 6) {
    return 2;
  } else if (month <= 9) {
    return 3;
  } else {
    return 4;
  }
}

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  print('quarter(3)  = ${quarter(3)}   | V2: ${quarterV2(3)}   (esperado 1)');
  print('quarter(8)  = ${quarter(8)}   | V2: ${quarterV2(8)}   (esperado 3)');
  print('quarter(11) = ${quarter(11)}   | V2: ${quarterV2(11)}   (esperado 4)');
}
