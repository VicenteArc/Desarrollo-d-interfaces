/// Kata: Valid Spacing (7 kyu)
///
/// Un texto tiene espaciado válido si hay exactamente un espacio entre
/// palabras y no hay espacios al principio ni al final.
library;

// ignore_for_file: non_constant_identifier_names

/// Comprueba si [text] tiene un espaciado válido.
///
/// Divide el texto por espacios. Si aparece alguna "palabra" vacía es porque
/// había dos espacios seguidos o un espacio al principio o al final.
/// El texto vacío se considera válido.
///
/// * [text]: texto a comprobar (solo letras y espacios).
///
/// Devuelve `true` si el espaciado es válido; `false` en caso contrario.
///
/// Ejemplo: `valid_spacing('Hello world')` devuelve `true`, y
/// `valid_spacing('Hello  world')` devuelve `false`.
bool valid_spacing(String text) {
  if (text == '') {
    return true;
  }

  List<String> palabras = text.split(' ');
  bool valido = true;

  for (int i = 0; i < palabras.length; i++) {
    if (palabras[i] == '') {
      valido = false;
    }
  }
  return valido;
}

/// Versión alternativa de [valid_spacing] sin bucles.
///
/// El espaciado es válido si el texto no cambia al quitarle los espacios
/// de los extremos (`trim`) y no contiene dos espacios seguidos.
///
/// * [text]: texto a comprobar (solo letras y espacios).
///
/// Devuelve `true` si el espaciado es válido; `false` en caso contrario.
bool validSpacingV2(String text) {
  return text == text.trim() && !text.contains('  ');
}

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  final pruebas = [
    ('Hello world', true),
    (' Hello world', false),
    ('Hello world  ', false),
    ('Hello  world', false),
    ('Hello', true),
    ('Helloworld', true),
    ('Helloworld ', false),
    (' ', false),
    ('', true),
  ];

  for (final (texto, esperado) in pruebas) {
    print("valid_spacing('$texto') = ${valid_spacing(texto)}"
        ' | V2: ${validSpacingV2(texto)} (esperado $esperado)');
  }
}
