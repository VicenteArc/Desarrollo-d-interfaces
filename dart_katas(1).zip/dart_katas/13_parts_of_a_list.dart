/// Kata: Parts of a list (7 kyu)
///
/// Devuelve todas las formas de partir una lista de palabras en dos partes
/// no vacías, uniendo cada parte con espacios.
library;

/// Genera todas las divisiones posibles de [arr] en dos partes.
///
/// Para cada punto de corte `i` (de 1 a `length - 1`), une con espacios
/// las palabras anteriores y las posteriores.
///
/// * [arr]: lista de palabras, con al menos 2 elementos.
///
/// Devuelve una lista de pares `[parte1, parte2]`.
///
/// Ejemplo: `partlist(['az', 'toto', 'picaro'])` devuelve
/// `[['az', 'toto picaro'], ['az toto', 'picaro']]`.
List<List<String>> partlist(List<String> arr) {
  List<List<String>> resultado = [];

  for (int i = 1; i < arr.length; i++) {
    String parte1 = arr.sublist(0, i).join(' ');
    String parte2 = arr.sublist(i).join(' ');

    resultado.add([parte1, parte2]);
  }

  return resultado;
}

/// Versión alternativa de [partlist] con [List.generate].
///
/// Hay `length - 1` puntos de corte posibles; [List.generate] crea un par
/// por cada uno usando [Iterable.take] y [Iterable.skip].
///
/// * [arr]: lista de palabras, con al menos 2 elementos.
///
/// Devuelve una lista de pares `[parte1, parte2]`.
List<List<String>> partlistV2(List<String> arr) {
  return List.generate(
    arr.length - 1,
    (i) => [arr.take(i + 1).join(' '), arr.skip(i + 1).join(' ')],
  );
}

/// Punto de entrada: prueba las dos versiones con un ejemplo del kata.
void main() {
  final palabras = ['I', 'wish', 'I', "hadn't", 'come'];
  print('partlist($palabras) =');
  print('  ${partlist(palabras)}');
  print('V2:');
  print('  ${partlistV2(palabras)}');
  print("Esperado: [[I, wish I hadn't come], [I wish, I hadn't come], "
      "[I wish I, hadn't come], [I wish I hadn't, come]]");
}
