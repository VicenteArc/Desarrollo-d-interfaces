/// Kata: Count Odd Numbers below n (8 kyu)
///
/// Dado un número n, devuelve cuántos números impares positivos hay por
/// debajo de n.
library;

/// Cuenta los números impares positivos menores que [n].
///
/// Entre 0 y n hay la mitad de impares, así que basta con la división
/// entera `n ~/ 2`. Funciona en tiempo constante, aunque n sea muy grande.
///
/// * [n]: número límite (no se incluye).
///
/// Devuelve la cantidad de impares positivos menores que [n].
///
/// Ejemplo: `oddCount(7)` devuelve `3` (1, 3 y 5).
int oddCount(int n) {
  return n ~/ 2;
}

/// Versión alternativa de [oddCount] con desplazamiento de bits.
///
/// Desplazar un bit a la derecha (`>> 1`) equivale a dividir entre 2
/// descartando los decimales.
///
/// * [n]: número límite (no se incluye), positivo.
///
/// Devuelve la cantidad de impares positivos menores que [n].
int oddCountV2(int n) {
  return n >> 1;
}

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  print('oddCount(7)     = ${oddCount(7)}    | V2: ${oddCountV2(7)}    (esperado 3)');
  print('oddCount(15)    = ${oddCount(15)}    | V2: ${oddCountV2(15)}    (esperado 7)');
  print('oddCount(15023) = ${oddCount(15023)} | V2: ${oddCountV2(15023)} (esperado 7511)');
}
