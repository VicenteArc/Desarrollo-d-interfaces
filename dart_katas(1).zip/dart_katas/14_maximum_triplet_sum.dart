/// Kata: Maximum Triplet Sum (Array Series #7) (7 kyu)
///
/// Suma los tres números más grandes de una lista sin repetir valores.
library;

/// Devuelve la suma de los 3 valores distintos más grandes de [nums].
///
/// Quita los repetidos con `toSet()`, ordena de menor a mayor y suma los
/// tres últimos.
///
/// * [nums]: lista de enteros (puede tener negativos y repetidos) con al
///   menos 3 valores distintos.
///
/// Devuelve la suma de los tres mayores valores distintos.
///
/// Ejemplo: `maxTriSum([3, 2, 6, 8, 2, 3])` devuelve `17` (8 + 6 + 3).
int maxTriSum(List<int> nums) {
  List<int> numerosUnicos = nums.toSet().toList();
  numerosUnicos.sort();
  int resultado = 0;

  for (int i = numerosUnicos.length - 3; i < numerosUnicos.length; i++) {
    resultado += numerosUnicos[i];
  }

  return resultado;
}

/// Versión alternativa de [maxTriSum] encadenando métodos.
///
/// Ordena de mayor a menor (`b.compareTo(a)`), coge los 3 primeros con
/// `take(3)` y los suma con `fold`.
///
/// * [nums]: lista de enteros con al menos 3 valores distintos.
///
/// Devuelve la suma de los tres mayores valores distintos.
int maxTriSumV2(List<int> nums) {
  final unicos = nums.toSet().toList()..sort((a, b) => b.compareTo(a));
  return unicos.take(3).fold(0, (suma, valor) => suma + valor);
}

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  final pruebas = [
    ([3, 2, 6, 8, 2, 3], 17),
    ([2, 9, 13, 10, 5, 2, 9, 5], 32),
    ([2, 1, 8, 0, 6, 4, 8, 6, 2, 4], 18),
    ([-3, -27, -4, -2, -27, -2], -9),
  ];

  for (final (lista, esperado) in pruebas) {
    print('maxTriSum($lista) = ${maxTriSum(lista)}'
        ' | V2: ${maxTriSumV2(lista)} (esperado $esperado)');
  }
}
