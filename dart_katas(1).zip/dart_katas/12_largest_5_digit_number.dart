/// Kata: Largest 5 digit number in a series (7 kyu)
///
/// Busca el mayor número de 5 cifras consecutivas dentro de un texto de
/// dígitos (de hasta 1000 cifras).
library;

/// Devuelve el mayor número formado por 5 cifras consecutivas de [digits].
///
/// Recorre el texto con una "ventana" de 5 caracteres, convierte cada
/// trozo a entero con [int.parse] y se queda con el mayor.
///
/// * [digits]: texto formado solo por dígitos, con al menos 5 caracteres.
///
/// Devuelve el mayor número de 5 cifras encontrado.
///
/// Ejemplo: `solution('1234567890')` devuelve `67890`.
int solution(String digits) {
  int mayor = 0;

  for (int i = 0; i <= digits.length - 5; i++) {
    int numero = int.parse(digits.substring(i, i + 5));

    if (numero > mayor) {
      mayor = numero;
    }
  }
  return mayor;
}

/// Versión alternativa de [solution] comparando textos.
///
/// Como todos los trozos tienen 5 caracteres, comparar los String con
/// [String.compareTo] da el mismo orden que comparar los números.
/// Solo se convierte a entero al final.
///
/// * [digits]: texto formado solo por dígitos, con al menos 5 caracteres.
///
/// Devuelve el mayor número de 5 cifras encontrado.
int solutionV2(String digits) {
  String mayor = digits.substring(0, 5);

  for (int i = 1; i <= digits.length - 5; i++) {
    String trozo = digits.substring(i, i + 5);
    if (trozo.compareTo(mayor) > 0) {
      mayor = trozo;
    }
  }
  return int.parse(mayor);
}

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  print("solution('1234567890') = ${solution('1234567890')}"
      " | V2: ${solutionV2('1234567890')} (esperado 67890)");
  print("solution('731674765') = ${solution('731674765')}"
      " | V2: ${solutionV2('731674765')} (esperado 74765)");
  print("solution('5434323453235423235776780') = ${solution('5434323453235423235776780')}"
      " | V2: ${solutionV2('5434323453235423235776780')} (esperado distinto de 0)");
}
