/// Kata: Reverse List Order (8 kyu)
///
/// Devuelve una lista con los elementos en orden inverso.
library;

/// Invierte el orden de una lista de enteros.
///
/// `reversed` devuelve un iterable en orden inverso y `toList()` lo
/// convierte en una lista nueva; la original no se modifica.
///
/// * [list]: lista de enteros a invertir.
///
/// Devuelve una lista nueva con los elementos al revés.
///
/// Ejemplo: `reverseList([1, 2, 3, 4])` devuelve `[4, 3, 2, 1]`.
List<int> reverseList(List<int> list) {
  return list.reversed.toList();
}

/// Versión alternativa de [reverseList] con un bucle `for`.
///
/// Recorre la lista desde el último índice hasta el primero y va
/// añadiendo cada elemento a una lista nueva.
///
/// * [list]: lista de enteros a invertir.
///
/// Devuelve una lista nueva con los elementos al revés.
List<int> reverseListV2(List<int> list) {
  List<int> resultado = [];
  for (int i = list.length - 1; i >= 0; i--) {
    resultado.add(list[i]);
  }
  return resultado;
}

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  print('reverseList([1, 2, 3, 4]) = ${reverseList([1, 2, 3, 4])}'
      ' | V2: ${reverseListV2([1, 2, 3, 4])} (esperado [4, 3, 2, 1])');
  print('reverseList([3, 1, 5, 4]) = ${reverseList([3, 1, 5, 4])}'
      ' | V2: ${reverseListV2([3, 1, 5, 4])} (esperado [4, 5, 1, 3])');
  print('reverseList([1]) = ${reverseList([1])}'
      ' | V2: ${reverseListV2([1])} (esperado [1])');
}
