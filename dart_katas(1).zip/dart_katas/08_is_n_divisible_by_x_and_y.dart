/// Kata: Is n divisible by x and y? (8 kyu)
///
/// Comprueba si un número es divisible a la vez por otros dos.
library;

/// Indica si [n] es divisible por [x] y también por [y].
///
/// Un número es divisible por otro si el resto (`%`) de la división es 0.
///
/// * [n]: número a comprobar (positivo, distinto de 0).
/// * [x]: primer divisor (positivo, distinto de 0).
/// * [y]: segundo divisor (positivo, distinto de 0).
///
/// Devuelve `true` si [n] es divisible por los dos; `false` en caso contrario.
///
/// Ejemplo: `isDivisible(12, 2, 6)` devuelve `true`.
bool isDivisible(int n, int x, int y) {
  return n % x == 0 && n % y == 0;
}

/// Versión alternativa de [isDivisible] usando el mínimo común múltiplo.
///
/// Si [n] es divisible por [x] y por [y], también lo es por su mcm.
/// El mcm se calcula como `x * y ~/ mcd(x, y)`, con [int.gcd] para el mcd.
///
/// * [n]: número a comprobar (positivo, distinto de 0).
/// * [x]: primer divisor (positivo, distinto de 0).
/// * [y]: segundo divisor (positivo, distinto de 0).
///
/// Devuelve `true` si [n] es divisible por los dos; `false` en caso contrario.
bool isDivisibleV2(int n, int x, int y) {
  int mcm = x * y ~/ x.gcd(y);
  return n % mcm == 0;
}

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  final pruebas = [
    (3, 3, 4, false),
    (12, 3, 4, true),
    (8, 3, 4, false),
    (48, 3, 4, true),
    (100, 5, 10, true),
    (100, 5, 3, false),
    (4, 4, 2, true),
  ];

  for (final (n, x, y, esperado) in pruebas) {
    print('isDivisible($n, $x, $y) = ${isDivisible(n, x, y)}'
        ' | V2: ${isDivisibleV2(n, x, y)} (esperado $esperado)');
  }
}
