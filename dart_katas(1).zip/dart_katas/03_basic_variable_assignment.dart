/// Kata: Basic variable assignment (8 kyu)
///
/// Hay que conseguir que la variable `name` valga `"codewa.rs"`.
library;

/// Primera parte del texto.
String a = 'code';

/// Segunda parte del texto.
String b = 'wa.rs';

/// Resultado de concatenar [a] y [b] con el operador `+`.
///
/// Vale `"codewa.rs"`.
String name = a + b;

/// Versión alternativa de [name] usando interpolación de cadenas.
///
/// `'$a$b'` inserta el valor de las dos variables dentro de un solo String.
/// Vale `"codewa.rs"`.
String nameV2 = '$a$b';

/// Punto de entrada: muestra las dos versiones.
void main() {
  print('name   = $name   (esperado codewa.rs)');
  print('nameV2 = $nameV2   (esperado codewa.rs)');
}
