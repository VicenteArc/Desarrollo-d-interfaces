/// Kata: Logical calculator (8 kyu)
///
/// Aplica un operador lógico (AND, OR o XOR) a todos los elementos de una
/// lista de booleanos, de izquierda a derecha.
library;

/// Aplica el operador [op] a todos los valores de [array] en orden.
///
/// Empieza con el primer valor y lo combina con cada uno de los siguientes.
/// Para XOR usa `!=`, que es verdadero solo si los dos valores son distintos.
///
/// * [array]: lista de booleanos, con al menos un elemento.
/// * [op]: operador a aplicar: `"AND"`, `"OR"` o `"XOR"`.
///
/// Devuelve el resultado de combinar todos los valores.
///
/// Ejemplo: `logicalCalc([true, true, false], "AND")` devuelve `false`.
bool logicalCalc(List<bool> array, String op) {
  bool resultado = array[0];

  for (int i = 1; i < array.length; i++) {
    if (op == 'AND') {
      resultado = resultado && array[i];
    } else if (op == 'OR') {
      resultado = resultado || array[i];
    } else if (op == 'XOR') {
      resultado = resultado != array[i];
    }
  }

  return resultado;
}

/// Versión alternativa de [logicalCalc] con `switch` y métodos de lista.
///
/// * AND: todos deben ser `true` (`every`).
/// * OR: basta con que uno sea `true` (`any`).
/// * XOR: `reduce` va combinando los valores de dos en dos con `!=`.
///
/// * [array]: lista de booleanos, con al menos un elemento.
/// * [op]: operador a aplicar: `"AND"`, `"OR"` o `"XOR"`.
///
/// Devuelve el resultado de combinar todos los valores.
/// Lanza [ArgumentError] si el operador no es válido.
bool logicalCalcV2(List<bool> array, String op) {
  switch (op) {
    case 'AND':
      return array.every((valor) => valor);
    case 'OR':
      return array.any((valor) => valor);
    case 'XOR':
      return array.reduce((acumulado, valor) => acumulado != valor);
    default:
      throw ArgumentError('Operador no válido: $op');
  }
}

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  final pruebas = [
    ([true, true, true, false], 'AND', false),
    ([true, true, true, false], 'OR', true),
    ([true, true, true, false], 'XOR', true),
    ([true, true, false, false], 'XOR', false),
    ([true, false, false, false], 'XOR', true),
    ([false, false], 'OR', false),
  ];

  for (final (lista, op, esperado) in pruebas) {
    print('logicalCalc($lista, $op) = ${logicalCalc(lista, op)}'
        ' | V2: ${logicalCalcV2(lista, op)} (esperado $esperado)');
  }
}
