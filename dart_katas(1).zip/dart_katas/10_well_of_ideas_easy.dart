/// Kata: Well of Ideas - Easy Version (8 kyu)
///
/// Cuenta las ideas buenas (`"good"`) de una lista y devuelve un mensaje.
library;

/// Evalúa una lista de ideas según cuántas son buenas.
///
/// * 0 ideas buenas: `"Fail!"`.
/// * 1 o 2 ideas buenas: `"Publish!"`.
/// * Más de 2 ideas buenas: `"I smell a series!"`.
///
/// * [x]: lista de ideas; cada una es `"good"` o `"bad"`.
///
/// Devuelve el mensaje correspondiente.
///
/// Ejemplo: `well(['good', 'bad', 'bad'])` devuelve `"Publish!"`.
String well(List<String> x) {
  int goods = 0;

  for (int i = 0; i < x.length; i++) {
    if (x[i] == 'good') {
      goods++;
    }
  }

  if (goods == 0) {
    return 'Fail!';
  } else if (goods <= 2) {
    return 'Publish!';
  } else {
    return 'I smell a series!';
  }
}

/// Versión alternativa de [well] con `where` y operadores ternarios.
///
/// `where` filtra las ideas que son `"good"` y `length` las cuenta.
///
/// * [x]: lista de ideas; cada una es `"good"` o `"bad"`.
///
/// Devuelve el mensaje correspondiente.
String wellV2(List<String> x) {
  int goods = x.where((idea) => idea == 'good').length;
  return goods == 0
      ? 'Fail!'
      : goods <= 2
          ? 'Publish!'
          : 'I smell a series!';
}

/// Punto de entrada: prueba las dos versiones con los ejemplos del kata.
void main() {
  final pruebas = [
    (['bad', 'bad', 'bad'], 'Fail!'),
    (['good', 'bad', 'bad', 'bad', 'bad'], 'Publish!'),
    (['good', 'bad', 'bad', 'bad', 'bad', 'good', 'bad', 'bad', 'good'], 'I smell a series!'),
  ];

  for (final (ideas, esperado) in pruebas) {
    print('well($ideas) = ${well(ideas)} | V2: ${wellV2(ideas)} (esperado $esperado)');
  }
}
